{
	"geoCodeError":"Oops! Adresse konnte nicht gefunden werden!",
	"locationSet":"Standort gesetzt auf",
	"resetTxt":"Position zurücksetzten"
}
